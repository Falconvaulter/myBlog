@extends('app')

@section('content')
Welcome/landing page
@endsection
